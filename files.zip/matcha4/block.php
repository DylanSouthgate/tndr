<?php
	session_start();
	require 'dbconnections.php';

	if (!$_SESSION['username'])
	{
		header("Location: login.php");
		exit();
	}
	echo $_GET['username'];

	if ($_GET['work'] == "block")
	{
		$sql = "INSERT INTO block (username, suspect) VALUES (?, ?)";
		$stmt = mysqli_stmt_init($conn);
		if (!mysqli_stmt_prepare($stmt ,$sql))
		{
			header("Location: registerform.php?error=SQL Error");
			exit();
		}
		else
		{
			mysqli_stmt_bind_param($stmt, "ss", $_SESSION['username'], $_GET['username']);
			mysqli_stmt_execute($stmt);
			header("Location: index.php");
			exit();
		}
	}
	else if ($_GET['work'] == "unblock")
	{
		$sql = "DELETE FROM block WHERE username='".$_SESSION['username']."' AND suspect='".$_GET['username']."'";
		if (mysqli_query($conn, $sql))
		{
			echo "Record deleted successfully";
		}
		else
		{
			echo "Error deleting record: " . mysqli_error($conn);
		}
	}
	
	

