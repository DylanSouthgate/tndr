<?php
	session_start();
	require 'dbconnections.php';


	if ($_SESSION['username'] && $_GET['username'])
	{
		$sql = "SELECT * FROM messages";
		$result = mysqli_query($conn, $sql);
		$resultCheck = mysqli_num_rows($result);
		if ($resultCheck > 0)
		{
			while ($row = mysqli_fetch_assoc($result))
			{
				if ($row['sender'] == $_SESSION['username'] && $row['reciever'] == $_GET['username'] || $row['sender'] == $_GET['username'] && $row['reciever'] == $_SESSION['username'])
				{
					if ($row['sender'] == $_SESSION['username'])
					{
						echo "You: ";
					}
					else
					{
						echo $row['sender'].": ";
					}
					echo $row['message']."<br>";
				}
			}
		}
	}
?>