<head>
	<style>
		*
		{
			text-decoration: none;
			color: black;
		}
		.row
		{
			display: flex;
            flex-direction: row;
            flex-wrap: wrap;
            justify-content: center;
		}
		.col
		{
			width: 250px;
			height: 300px;
			text-align: center;
		}
		.col p
		{
			margin: 0px;
			text-decoration: none;
		}
		.image
		{
			text-align: center;
		}
		img {
			height: 160px;
			width: 160px;
		}
	</style>
</head>
<?php
	session_start();
	require 'dbconnections.php';
	include 'userdata.php';

	if (!$_SESSION['username'])
	{
		header("Location: loginform.php");
		exit();
	}
	else
	{
		$i = 0;
		$j = 0;
		$string = " SELECT * FROM userprofile";
		if ($_GET['agemin'] || $_GET['agemax'] || $_GET['popmin'] || $_GET['popmax'] || $_GET['location'] || $_GET['tags'] || $_GET['Sexual_Orientation'] || $_GET['gender'])
		{
			$string .= " WHERE";
		}
		if ($_GET['agemin'])
		{
			$string .= " age>='".$_GET['agemin']."'";
			$i++;
		}
		if ($_GET['agemax'])
		{
			if ($i > 0)
				$string .= " AND";
			$string .= " age<='".$_GET['agemax']."'";
			$i++;
		}
		if ($_GET['popmin'])
		{
			if ($i > 0)
				$string .= " AND";
			$string .= " popularity_score>='".$_GET['popmin']."'";
			$i++;
		}
		if ($_GET['popmax'])
		{
			if ($i > 0)
				$string .= " AND";
			$string .= " popularity_score<='".$_GET['popmax']."'";
			$i++;
		}
		if ($_GET['location'])
		{
			if ($i > 0)
				$string .= " AND";
			$string .= " location='".$_GET['location']."'";
			$i++;
		}
		if ($_GET['gender'])
		{
			if ($i > 0)
				$string .= " AND";
			$string .= " gender='".$_GET['gender']."'";
			$i++;
		}
		if ($_GET['Sexual_Orientation'])
		{
			if ($i > 0)
				$string .= " AND";
			$string .= " Sexual_Orientation='".$_GET['Sexual_Orientation']."'";
			$i++;
		}
		if ($_GET['tags'])
		{
			if ($i > 0)
				$string .= " AND";
			$string .= " (interest1='".$_GET['tags']."' OR interest2='".$_GET['tags']."' OR interest3='".$_GET['tags']."')";
			$i++;
		}
		
		if ($_GET['orderage'])
		{
			$string .= " ORDER BY";
			$string .= " ".$_GET['orderage'];
			$j++;
		}

		if ($_GET['orderlocation'])
		{
			if ($j > 0)
				$string .= ", ";
			else if ($j == 0)
				$string .= " ORDER BY";
			$string .= " ".$_GET['orderlocation'];
			$j++;
		}

		if ($_GET['orderpopularity'])
		{
			if ($j > 0)
				$string .= ", ";
			else if ($j == 0)
				$string .= " ORDER BY";
			$string .= " ".$_GET['orderpopularity'];
			$j++;
		}

		if ($_GET['ordertags'])
		{
			if ($j > 0)
				$string .= ", ";
			else if ($j == 0)
				$string .= " ORDER BY";
			$string .= " ".$_GET['ordertags'];
			$j++;
		}

		
		
//		echo $string;
		
		$row = selectby($conn, $string);
		$block = checkblock($conn, $_SESSION['username']);
		echo '<div class="row">';
		for ($j = 0; $j < count($row); $j++)
		{
			if(in_array($row[$j]['username'], $block, TRUE)) 
			{
				continue;
			} 
			
			echo '<div class="col test">';
			echo "<a target='_blank' href=http://localhost:8888/visitprofile.php?username=".$row[$j]['username'].">";
				echo "<img class='image center'src='images/".$row[$j]['profile_picture']."'>";
				echo "<p class='name'>Name: ".$row[$j]['firstname']." ".$row[$j]['lastname']."</p>";
				echo "<p class='age'>Age: ".$row[$j]['age']."</p>";
				echo "<p class='popularity_score'>Pop score: ".$row[$j]['popularity_score']."</p>";
				echo "<div class='tags'>Interests: ".$row[$j]['interest1']." ";
				echo $row[$j]['interest2']." ";
				echo $row[$j]['interest3']."</div>";
				echo '</a>';
			echo '</div>';

		}
		echo '</div>';
	}
?>