<?php
	include 'header.php';
?>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
<div class="container">
	<form action="register.php" method="post">
		<h1>Register</h1>
		<p>Please fill in this form to create an account.</p>

		<h3><?php if (isset($_GET['error'])) { echo "Error: ".$_GET['error']; }?></h3>

		<label for="username"><b>Username</b></label>
		<input type="text" class="form-control" value="<?php echo $_GET['username'];?>" placeholder="Enter Username" name="username" id="username" required>

		<label for="firstname"><b>First Name</b></label>
		<input type="text" class="form-control" value="<?php echo $_GET['firstname'];?>" placeholder="Enter First Name" name="firstname" id="firstname" required>

		<label for="lastname"><b>Surname</b></label>
		<input type="text" class="form-control" value="<?php echo $_GET['lastname'];?>" placeholder="Enter lastname" name="lastname" id="lastname" required>

		<label for="email"><b>Email</b></label>
		<input type="text" class="form-control" value="<?php echo $_GET['email'];?>" placeholder="Enter Email" name="email" id="email" required>

		<label for="pwd"><b>Password</b></label>
		<input type="password" class="form-control" placeholder="Enter Password" name="pwd" id="pwd" required>

		<label for="pwd2"><b>Repeat Password</b></label>
		<input type="password" class="form-control" placeholder="Enter Repeat Password" name="pwd2" id="pwd2" required>

		<button type="submit" name="signup-submit" class="btn btn-primary">Register</button>
		</form>
	<div class="container signin">
		<p>Already have an account? <a href="loginform.php">Sign in</a>.</p>
	</div>
</div>
