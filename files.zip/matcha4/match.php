<?php

	include 'header.php';
	require 'dbconnections.php';
//	require 'userdata.php';

	if (!$_SESSION['username'])
	{
		header("Location: loginform.php");
		exit();
	}
	else
	{
		$string = "SELECT * FROM likes WHERE (emailliker='".$_SESSION['username']."' AND recieveliker='".$_GET['username']."' AND status='like') OR (recieveliker='".$_SESSION['username']."' AND emailliker='".$_GET['username']."' AND status='like')";
//		$match = selectby($conn, $string);
		$sqlstring = $string;
		$results = $conn->query($sqlstring);

		if ($results->num_rows > 1)
		{
			$sql = "INSERT INTO notifications (emailsender, emailreciever,message, stat) VALUES (?,?,?,?)";
			$stmt = mysqli_stmt_init($conn);
			if (!mysqli_stmt_prepare($stmt ,$sql))
			{
			}
			else
			{
				$liker = $_GET['username'];
				$recieveliker = $_SESSION['username'];
				$message = "match";
				$read = "unread";
				mysqli_stmt_bind_param($stmt, "ssss", $liker, $recieveliker, $message, $read);
				mysqli_stmt_execute($stmt);
			}
			$sql = "INSERT INTO notifications (emailsender, emailreciever,message, stat) VALUES (?,?,?,?)";
			$stmt = mysqli_stmt_init($conn);
			if (!mysqli_stmt_prepare($stmt ,$sql))
			{
			}
			else
			{
				$liker = $_SESSION['username'];
				$recieveliker = $_GET['username'];
				$message = "match";
				$read = "unread";
				mysqli_stmt_bind_param($stmt, "ssss", $liker, $recieveliker, $message, $read);
				mysqli_stmt_execute($stmt);
			}
			header("Location: allprofile.php?username=".$_GET['username']);
			exit();
		}
		header("Location: allprofile.php?username=".$_GET['username']);
			exit();
	}