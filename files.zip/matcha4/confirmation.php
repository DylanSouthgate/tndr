<?php
include 'header.php';
	if (isset($_GET['email']) && isset($_GET['token']))
	{
		$email = $_GET['email'];
		$emailtoken = md5($_GET['email']);
		$token = $_GET['token'];

		if ($emailtoken == $token)
		{
			require 'dbconnections.php';
			echo "success";

			$sql = "SELECT * FROM userprofile WHERE email='".$email."'";
			$result = mysqli_query($conn, $sql);

			$resultCheck = mysqli_num_rows($result);
			if ($resultCheck > 0)
			{
				echo "account found.";
				$test = "UPDATE userprofile SET confirmation='yes' WHERE email='".$email."'";
				$sql = $test;
				if ($conn->query($sql) === TRUE)
				{
					echo "Record updated successfully";
					header("Location: loginform.php?message=Email address confirmed.");
					exit();
				}
				else
				{
					echo "Error updating record: " . $conn->error;
					header("Location: loginform.php?error=Failed to confirm email address.");
					exit();
				}
				$conn->close();
			}
		}
	}
	else
	{
		header("Location: index.php");
		exit();
	}

?>