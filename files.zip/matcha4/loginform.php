<?php include 'header.php'?>
<form action="login.php" method="post">
	<div class="container">
		<h1>Login</h1>

		<h3><?php if (isset($_GET['error'])) { echo "Error: ".$_GET['error']; }?></h3>
		<h3><?php if (isset($_GET['message'])) { echo $_GET['message']; }?></h3>

		<label for="email"><b>Email</b></label>
		<input type="text" class="form-control" value="<?php echo $_GET['email'];?>" placeholder="Enter Email" name="email" id="email" required>

		<label for="pwd"><b>Password</b></label>
		<input type="password" class="form-control" placeholder="Enter Password" name="pwd" id="pwd" required>

		<button type="submit" name="login-submit" class="btn btn-primary">Login</button>

	</div>

	<div class="container signin">
		<p>Don't have an account? <a href="registerform.php">Sign Up</a>.</p>
		<p>Don't have an account? <a href="password_reset.php">Password Reset</a>.</p>
	</div>
</form>