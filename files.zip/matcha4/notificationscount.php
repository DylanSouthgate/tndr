<?php
	session_start();
	require 'dbconnections.php';

	if ($_SESSION['username'])
	{
		$sql = "SELECT * FROM notifications WHERE emailreciever='".$_SESSION['username']."' AND stat='unread'";
		$result = mysqli_query($conn, $sql);
		$resultCheck = mysqli_num_rows($result);
		echo $resultCheck;
	}
?>