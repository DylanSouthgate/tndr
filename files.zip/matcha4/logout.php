<?php
	require 'dbconnections.php';
	session_start();
	if ($_SESSION['username'])
	{
		$test = "UPDATE lastseen SET lastseendate='".date(DATE_RFC2822)."' WHERE username='".$_SESSION['username']."'";
		$conn->query($test);
		$test = "UPDATE lastseen SET status='offline' WHERE username='".$_SESSION['username']."'";
		$conn->query($test);
	}
	session_unset();
	session_destroy();
	header("Location: index.php");
	exit();
?>