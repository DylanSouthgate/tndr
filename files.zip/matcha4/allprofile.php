<?php 

	include 'header.php';
	require 'dbconnections.php';
	include 'userdata.php';

	if ($_GET['username'] && $_GET['profile'])
	{
		$sql = "SELECT * FROM userprofile WHERE username='".$_GET['username']."'";
		$result = mysqli_query($conn, $sql);
		$resultCheck = mysqli_num_rows($result);
		if ($resultCheck > 0)
		{
			$row = mysqli_fetch_assoc($result);
		}
		else
		{
			echo "User not found.";
		}

		$sql = "SELECT * FROM likes WHERE emailliker='".$_SESSION['username']."' AND recieveliker='".$row['username']."'";
		$result = mysqli_query($conn, $sql);
		$resultCheck = mysqli_num_rows($result);
		if ($resultCheck > 0)
		{
			$like = mysqli_fetch_assoc($result);
		}
		if ($like['status'] == "like")
		{
			echo "<a href=/likeprofile.php?reciever=".$row['username']."&username=".$_GET['username']."&status=dislike><button>Dislike</button</a>";
		}
		else if ($like['status'] == "dislike" || !$like)
		{
			echo "<a href=/likeprofile.php?reciever=".$row['username']."&username=".$_GET['username']."&status=like><button>Like</button></b</a>";
		}
		echo "<a href=/chatapp.php?username=".$row['username']."><button>Message</button></a>";
		echo "<a href=/block.php?username=".$row['username']."&work=block><button>Block</button></a>";
		$sql = "SELECT * FROM lastseen WHERE username='".$row['username']."'";
		$result = mysqli_query($conn, $sql);
		$resultCheck = mysqli_num_rows($result);
		$details = mysqli_fetch_assoc($result);
		if ($details['status'] == "offline")
		{
			echo "<p class='offline'>Offline</p>";
			echo "lastseen: ".$details['lastseendate'];
		}
		else if ($details['status'] == "online")
		{
			echo "<p class='online'>Online</p>";
		}
		else
		{
			echo "<p class='offline'>Offline</p>";
			echo "lastseen: ".$details['lastseendate'];
		}

	}
	else
	{
		header("Location: visitprofile.php?username=".$_GET['username']);
		exit();
	}
?>
<head>
	<style>
		div.gallery
		{
			padding: 2px;
			border: 1px solid #ccc;
			float: left;
			width: 270px;
			height: 324px;
		}
		div.gallery:hover{
  			border: 1px solid #777;
		}
		div.gallery img {
			width: 100%;
			height: auto;
		}
		div.desc {
			padding: 15px;
			text-align: center;
		}
		.buttons 
		{
			text-align: center;
		}
		.offline
		{
			color: red;
			padding: 2px;
		}
		.online
		{
			color: green;
			padding: 2px;
		}
	</style>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
</head>
<body>
	<div class="buttons">
		<a href="/allprofile.php?username=<?php echo $_GET['username']; ?>&page=1&profile=1"><button>User Details</button></a>
		<a href="/allprofile.php?username=<?php echo $_GET['username']; ?>&page=2&profile=2"><button>Personal Details</button></a>
		<a href="/allprofile.php?username=<?php echo $_GET['username']; ?>&page=3&profile=3"><button>Pictures</button></a>
	</div>
	<div class="data">
		<form action="allprofile.php" method="post">
		<?php if ($_GET['page'] == 1) {?>
			<label for="username"><b>Username</b></label>
			<input type="text" class="form-control" value="<?php echo $row['username'];?>" name="username" id="username" required><br>
			<label for="firstname"><b>First Name</b></label>
			<input type="text" class="form-control" value="<?php echo $row['firstname'];?>" name="firstname" id="firstname" required><br>
			<label for="lastname"><b>Last Name</b></label>
			<input type="text" class="form-control" value="<?php echo $row['lastname'];?>" name="lastname" id="lastname" required><br>
			<label for="popularity_score"><b>Popular Score</b></label>
			<input type="text" class="form-control" value="<?php echo $row['popularity_score'];?>" name="popularity_score" id="popularity_score" required READONLY/><br>
			<label for="location"><b>Location</b></label>
			<input type="text" class="form-control" value="<?php echo $row['location'];?>" name="location" id="location" required><br>
			</form>
		<form action="allprofile.php" method="post">
		<?php } else if ($_GET['page'] == 2) { ?>
			<label for="age"><b>Age</b></label>
			<input type="text" class="form-control" value="<?php echo $row['age'];?>" name="age" id="age" required><br>
			<label for="gender"><b>Gender</b></label>
			<input type="text" class="form-control" value="<?php echo $row['gender'];?>" name="gender" id="gender" required><br>
			<label for="sexual_orientation"><b>Sexual Orientation</b></label>
			<input type="text" class="form-control" value="<?php echo $row['sexual_orientation'];?>" name="sexual_orientation" id="sexual_orientation" required><br>
			<label for="shortbio"><b>Short Bio</b></label>
			<input type="text" class="form-control" value="<?php echo $row['shortbio'];?>" name="shortbio" id="shortbio" required><br>
			<label for="interests"><b>Interests</b></label>
			<input type="text" class="form-control" value="<?php echo $row['interest1']." "; echo $row['interest2']." "; echo $row['interest3']." ";?>" name="interests" id="interests" required><br>
			</form>
			<form action="allprofile.php" method="post">
		<?php } else if ($_GET['page'] == 3) { ?>
			<div class="gallery">
				<img src='images/<?php echo $row['profile_picture'];?>' alt='Cinque Terre' width='270' height='270'>
				<div class='desc'>Profile Picture</div>
			</div>
			<div class="gallery">
				<img src='images/<?php echo $row['picture1'];?>' alt='Cinque Terre' width='270' height='270'>
				<div class='desc'>1</div>
			</div>
			<div class="gallery">
				<img src='images/<?php echo $row['picture2'];?>' alt='Cinque Terre' width='270' height='270'>
				<div class='desc'>2</div>
			</div>
			<div class="gallery">
				<img src='images/<?php echo $row['picture3'];?>' alt='Cinque Terre' width='270' height='270'>
				<div class='desc'>3</div>
			</div>
			<div class="gallery">
				<img src='images/<?php echo $row['picture4'];?>' alt='Cinque Terre' width='270' height='270'>
				<div class='desc'>4</div>
			</div>
		<?php } ?>
		</form>
	</div>
</body>