<?php 

	include 'header.php';
//	include 'profilecomplete.php';
	require 'dbconnections.php';
	include 'userdata.php';
//	include 'geo.php';

	if (!$_SESSION['username'])
	{
		header("Location: loginform.php");
		exit();
	}


	if ($_GET['error'])
	{
		echo "Error:".$_GET['error'];
	}

	if ($_SESSION['username'])
	{
//		geolocation($conn, $_SESSION['username']);
		$row = getdatabyusername($conn, $_SESSION['username']);
		if (!$row['location'])
		{
			geolocation($conn, $_SESSION['username']);
		}

	}
?>
<style>
	img
	{
		width: 160px;
		height: 160px;
	}
	.row-row
	{
		display: flex;
		flex-direction: row;
		flex-wrap: wrap;
		justify-content: center;
	}
	.col-row
	{
		width: 250px;
		height: 300px;
		text-align: center;
	}
</style>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
<body>
<div class="container">
	<div class="row justify-content-md-center">
		<a href="/profile.php" class="button">User Details</a>
		<a href="/profile.php?page=2" class="button">Personal Details</a>
		<a href="/profile.php?page=3" class="button">Pictures</a>
	</div>
	<div class="">
		<?php if (!$_GET['page']) {?>
			<div class="page1">
				<form action="updatepage1.php?page=1" method="post">
					<div class="form-label">
						<img src='images/<?php echo $row['profile_picture'];?>' class='pics1'>
					</div>
					<div class="form-label">
						<label for="username"><b class="lab">Username</b></label>
						<input type="text" class="form-control" value="<?php echo $row['username'];?>" name="username" id="username" required><br>
					</div>
					<div class="form-label">
						<label for="firstname"><b class="lab">First Name</b></label>
						<input type="text" class="form-control" value="<?php echo $row['firstname'];?>" name="firstname" id="firstname" required><br>
					</div>
					<div class="form-label">
						<label for="lastname"><b class="lab">Last Name</b></label>
						<input type="text" class="form-control" value="<?php echo $row['lastname'];?>" name="lastname" id="lastname" required><br>
					</div>
					<div class="form-label">
						<label for="popularity_score"><b class="lab">Popular Score</b></label>
						<input type="text" class="form-control" value="<?php echo $row['popularity_score'];?>" name="popularity_score" id="popularity_score" required READONLY/><br>
					</div>
					<div class="form-label">
						<label for="location"><b class="lab">Location</b></label>
						<input type="text" class="form-control" value="<?php echo $row['location'];?>" name="location" id="location" required><br>
					</div>
					<div class="form-label">
						<button type="submit" name="page1" class="button">Save</button>
					</div>
				</form>
			</div>
	</div>
</div>

		<?php } else if ($_GET['page'] == 2) { ?>
<div class="container">
			<div class="page1">
				<form action="updateprofile.php?page=2" method="post">
					<div class="form-label">
						<label for="age"><b class="lab">Age</b></label>
						<input type="text" class="form-control" value="<?php echo $row['age'];?>" name="age" id="age" required><br>
					</div>
					<div class="form-label">
						<label for="gender"><b class="lab">Gender</b></label>
						<select id="gender" name="gender" value="<?php echo $row['gender'];?>" required>
							<option value="<?php echo $row['gender'];?>" selected><?php echo $row['gender'];?></option>
							<option value="male">male</option>
							<option value="female">female</option>
							<option value="Other">other</option>
						</select><br>
					</div>
					<div class="form-label">
						<label for="sexual_orientation"><b class="lab">Sexual Orientation</b></label>
						<select id="sexual_orientation" name="sexual_orientation">
							<option value="<?php echo $row['sexual_orientation'];?>" selected><?php echo $row['sexual_orientation'];?></option>
							<option value="Heterosexual">Heterosexual</option>
							<option value="Homosexual">Homosexual</option>
							<option value="Bisexual">Bisexual</option>
							<option value="Other">Other</option>
						</select><br>
					</div>
					<div class="form-label">
						<label for="shortbio"><b class="lab">Short Bio</b></label>
						<input type="text" class="form-control" value="<?php echo $row['shortbio'];?>" name="shortbio" id="shortbio" required><br>
					</div>
					<?php include 'interests.php'; ?>
					<div class="form-label">
						<p>Popular tags: <?php echo $interest1;?></p>
						<label for="interest1"><b class="lab">Interest 1</b></label>
						<input type="text" class="form-control" value="<?php echo $row['interest1'];?>" name="interest1" id="interest1" required><br>
					</div>
					<div class="form-label">
						<p>Popular tags: <?php echo $interest2;?></p>
						<label for="interest2"><b class="lab">Interest 2</b></label>
						<input type="text" class="form-control" value="<?php echo $row['interest2'];?>" name="interest2" id="interest2" required><br>
					</div>
					<div class="form-label">
						<p>Popular tags: <?php echo $interest3;?></p>
						<label for="interest3"><b class="lab">Interest 3</b></label>
						<input type="text" class="form-control" value="<?php echo $row['interest3'];?>" name="interest3" id="interest3" required><br>
					</div>
					<div class="form-label">
						<button type="submit" name="page2" class="button">Save</button>
					</div>
				</form>
		</div>
	</div>
</div>

		<?php } else if ($_GET['page'] == 3) { ?>
			<div class="row-row">
				<div class="col-row">
					<img src='images/<?php echo $row['profile_picture'];?>' class='pics'>
					<div class='desc'>Profile Picture</div>
					<form action="updateprofile.php?page=3&name=profile_picture" method="post" enctype="multipart/form-data">
						<div><input type="file" name="profile_picture" id="fileSelect"></div>
						<div><input type="submit" name="Upload" value="Upload"></div>
						</form>
				</div>
				<div class="col-row">
					<img src='images/<?php echo $row['picture1'];?>'height="120">
					<div class='desc'>1</div>
					<form action="updateprofile.php?page=3&name=picture1" method="post" enctype="multipart/form-data">
						<div><input type="file" name="picture1" id="fileSelect"></div>
						<div><input type="submit" name="Upload" value="Upload"></div>
					</form>
				</div>
				<div class="col-row">
					<img src='images/<?php echo $row['picture2'];?>' alt='Cinque Terre' width='270'>
					<div class='desc'>2
					<form action="updateprofile.php?page=3&name=picture2" method="post" enctype="multipart/form-data">
						<div><input type="file" name="picture2" id="fileSelect"></div>
						<div><input type="submit" name="Upload" value="Upload"></div>
					</form></div>
				</div>
				<div class="col-row">
					<img src='images/<?php echo $row['picture3'];?>' alt='Cinque Terre' width='270' height='270'>
					<div class='desc'>3</div>
					<form action="updateprofile.php?page=3&name=picture3" method="post" enctype="multipart/form-data">
						<div><input type="file" name="picture3" id="fileSelect"></div>
						<div><input type="submit" name="Upload" value="Upload"></div>
					</form>
				</div>
				<div class="col-row">
					<img src='images/<?php echo $row['picture4'];?>' alt='Cinque Terre' width='270' height='270'>
					<div class='desc'>4</div>
					<form action="updateprofile.php?page=3&name=picture4" method="post" enctype="multipart/form-data">
						<div class="input"><input type="file" name="picture4" id="fileSelect"></div>
						<div class="input"><input type="submit" name="Upload" value="Upload"></div>
					</form>
				</div>
				<a href="instagram.php">Upload images from instagram.</a>
			</div>
		<?php } ?>
</body>