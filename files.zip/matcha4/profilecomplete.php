<?php

	session_start();
	require 'dbconnections.php';

	if ($_SESSION['username'])
	{
		$sql = "SELECT * FROM userprofile WHERE username='".$_SESSION['username']."'";
		$result = mysqli_query($conn, $sql);
		$resultCheck = mysqli_num_rows($result);
		if ($resultCheck > 0)
		{
			$row = mysqli_fetch_assoc($result);
			if (!$row['age'] || !$row['gender'] || !$row['sexual_orientation'] || !$row['shortbio'] || !$row['interest1'] || !$row['interest2'] || !$row['interest3'] || !$row['profile_picture'] || !$row['picture1'] || !$row['picture2'] || !$row['picture3'] || !$row['picture4'] || !$row['location'])
			{
				echo "Not Completed";
				$test = "UPDATE userprofile SET completed='no' WHERE username='".$_SESSION['username']."'";
				$conn->query($test);
				header("Location: profile.php");
				exit();
			}
			else
			{

				$test = "UPDATE userprofile SET completed='yes' WHERE username='".$_SESSION['username']."'";
				$conn->query($test);
				header("Location: index.php");
				exit();
			}
		}
	}
	else
	{
		header("Location: index.php");
					exit();
	}