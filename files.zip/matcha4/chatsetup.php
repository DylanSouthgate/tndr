<?php

	if (isset($_POST['send-submit']))
	{
		require 'dbconnections.php';

		$sender = $_POST['sender'];
		$message = $_POST['message'];
		$reciever = $_POST['reciever'];
		$chatid = $sender.$reciever;
		$status = "unread";

		$sql = "INSERT INTO messages (sender, reciever, message, stat) VALUES (?, ?, ?, ?)";
		$stmt = mysqli_stmt_init($conn);
		if (!mysqli_stmt_prepare($stmt ,$sql))
		{
			header("Location: chatapp.php?sender=".$_POST['sender']."&rec=".$_POST['reciever']);
			exit();
		}
		else
		{
			mysqli_stmt_bind_param($stmt, "ssss", $sender, $reciever,$message, $status);
			mysqli_stmt_execute($stmt);
			$sql = "INSERT INTO notifications (emailsender, emailreciever, message, stat) VALUES (?, ?, ?, ?)";
			$stmt = mysqli_stmt_init($conn);
			if (!mysqli_stmt_prepare($stmt ,$sql))
			{
				header("Location: chatapp.php?sender=".$_POST['sender']."&rec=".$_POST['reciever']);
				exit();
			}
			else
			{
				$message = "sent you a message.";
				mysqli_stmt_bind_param($stmt, "ssss", $sender, $reciever,$message, $status);
				mysqli_stmt_execute($stmt);
			}
			header("Location: chatapp.php?username=".$reciever."");
			exit();
		}
	}
	else
	{
		echo "didnt work";
	}
?>