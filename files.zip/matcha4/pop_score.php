<?php
	session_start();
	require 'dbconnections.php';

	if ($_SESSION['username'])
	{
		$sql = "SELECT * FROM userprofile";
		$result = mysqli_query($conn, $sql);
		$resultCheck = mysqli_num_rows($result);
		$numberofusers = $resultCheck;
		$sql = "SELECT * FROM likes WHERE recieveliker='".$_SESSION['username']."' AND status='like'";
		$result = mysqli_query($conn, $sql);
		$resultCheck = mysqli_num_rows($result);
		$numberoflikes = $resultCheck;

		$popscore = $numberoflikes / $numberofusers * 100;

		$test = "UPDATE userprofile SET popularity_score='".$popscore."' WHERE username='".$_SESSION['username']."'";
		if ($conn->query($test) === TRUE)
		{
			echo "yes";
			header("Location: profile.php");
			exit();
		}
		else
		{
			echo "nope";
			header("Location: profile.php");
			exit();
		}
	}