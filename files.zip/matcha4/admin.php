<?php
	require 'dbconnections.php';
	include 'userdata.php';

	$row = checkblock($conn, $username);