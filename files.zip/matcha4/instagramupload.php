<?php
	include 'header.php';
	require 'dbconnections.php';

//	$url ='';

//	$img = 'logo.png';  

//	file_put_contents($img, file_get_contents($url)); 

//	echo "File downloaded!"

	if (isset($_POST['upload']))
	{
		$image_select = mysqli_real_escape_string($conn,$_POST['image']);
		$image_link = mysqli_real_escape_string($conn,$_POST['link']);

		echo $image_select;
		echo $image_link;

		$url = $image_link;

		$str=rand();
		$result = md5($str); 

		$img = "images/".$result.".jpg";

		$name = $result.".jpg";

		file_put_contents($img, file_get_contents($url));


		$test = "UPDATE userprofile SET ".$image_select."='".$name."' WHERE username='".$_SESSION['username']."'";
		if ($conn->query($test) === TRUE)
		{
			header("Location: profile.php?page=3");
		}

	}
  
?> 