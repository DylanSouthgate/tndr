<?php

	include 'header.php';
	require 'dbconnections.php';

	if (!$_SESSION['username'])
	{
		header("Location: loginform.php");
		exit();
	}

	if ($_GET['page'] == 2 && isset($_POST['page2']))
	{
		$age = mysqli_real_escape_string($conn, $_POST['age']);
		$gender = mysqli_real_escape_string($conn,$_POST['gender']);
		$sexual_orientation = mysqli_real_escape_string($conn,$_POST['sexual_orientation']);
		$shortbio = mysqli_real_escape_string($conn,$_POST['shortbio']);
		$interest1 = mysqli_real_escape_string($conn,$_POST['interest1']);
		$interest2 = mysqli_real_escape_string($conn,$_POST['interest2']);
		$interest3 = mysqli_real_escape_string($conn,$_POST['interest3']);

		$test = "UPDATE userprofile SET age='".$age."', gender='".$gender."', sexual_orientation='".$sexual_orientation."', shortbio='".$shortbio."', interest1='".$interest1."', interest2='".$interest2."', interest3='".$interest3."' WHERE username='".$_SESSION['username']."'";

		if ($conn->query($test) === TRUE)
		{
			echo "Record updated successfully";
			header("Location: profile.php");
			exit();
		}
		else
		{
			echo "Error updating record: " . $conn->error;
			header("Location: profile.php?error=SQL");
			exit();
		}
		$conn->close();
		header("Location: profile.php");
		exit();
	}
	if ($_GET['page'] == 3 && isset($_POST['Upload']))
	{
		$filename = $_GET['name'].$_SESSION['username'].".jpg";
		if(file_exists("images/" . $filename))
		{
//			echo $filename . " is already exists.";
			unlink("images/" . $filename);
			move_uploaded_file($_FILES[$_GET['name']]["tmp_name"], "images/" . $filename);
		}
		else
		{
			move_uploaded_file($_FILES[$_GET['name']]["tmp_name"], "images/" . $filename);
		}
		$test = "UPDATE userprofile SET ".$_GET['name']."='".$filename."' WHERE username='".$_SESSION['username']."'";
		if ($conn->query($test) === TRUE)
		{
//			echo "Record updated successfully";
			header("Location: profile.php?page=3");
			exit();
		}
		else
		{
//			echo "Error updating record: " . $conn->error;
			header("Location: profile.php?error=SQL");
			exit();
		}
		//$conn->close();
		//header("Location: profile.php?page=3");
		//exit();
	}