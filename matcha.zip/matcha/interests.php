<?php
	session_start();
	require 'dbconnections.php';
	if ($_SESSION['username'])
	{
		$sql = "SELECT DISTINCT interest1 FROM userprofile";
		$result = mysqli_query($conn, $sql);
		$resultCheck = mysqli_num_rows($result);
		if($resultCheck > 0)
		{
			while ($row1 = mysqli_fetch_assoc($result))
			{
				$interest1 .= $row1['interest1']." ";
			}
		}
		$sql = "SELECT DISTINCT interest2 FROM userprofile";
		$result = mysqli_query($conn, $sql);
		$resultCheck = mysqli_num_rows($result);
		if($resultCheck > 0)
		{
			while ($row2 = mysqli_fetch_assoc($result))
			{
				$interest2 .= $row2['interest2']." ";	
			}
		}
		$sql = "SELECT DISTINCT interest3 FROM userprofile";
		$result = mysqli_query($conn, $sql);
		$resultCheck = mysqli_num_rows($result);
		if($resultCheck > 0)
		{
			while ($row3 = mysqli_fetch_assoc($result))
			{
				$interest3 .= $row3['interest3']." ";
			}
		}
	}