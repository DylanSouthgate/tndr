<?php
	session_start();
	require 'dbconnections.php';

	if ($_SESSION['username'] && $_GET['username'])
	{
		$liker = $_SESSION['username'];
		$recieve = $_GET['username'];

		$sql = "SELECT * FROM userprofile WHERE username='".$recieve."'";
		$result = mysqli_query($conn, $sql);
		$resultCheck = mysqli_num_rows($result);
		if ($resultCheck > 0)
		{
			echo "found user.";
			$row = mysqli_fetch_assoc($result);
				$recieveemail = $row['username'];
				$sql = "INSERT INTO notifications (emailsender, emailreciever,message, stat) VALUES (?,?,?,?)";
				$stmt = mysqli_stmt_init($conn);
				if (!mysqli_stmt_prepare($stmt ,$sql))
				{
//					header("Location: allprofile.php?username=".$recieve."");
//					exit();
				}
				else
				{
					$status = "visited your profile.";
					$read = "unread";
					mysqli_stmt_bind_param($stmt, "ssss", $liker, $recieveemail, $status, $read);
					mysqli_stmt_execute($stmt);
					header("Location: allprofile.php?username=".$recieve."&profile=".$recieve."");
					exit();
				}
		}
	}
?>