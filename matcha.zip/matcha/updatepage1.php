<?php
	include 'header.php';
	require 'dbconnections.php';

	if (!$_SESSION['username'])
	{
		header("Location: loginform.php");
		exit();
	}
	if (isset($_POST['page1']))
	{
		$username = mysqli_real_escape_string($conn,$_POST['username']);
		$firstname = mysqli_real_escape_string($conn,$_POST['firstname']);
		$surname = mysqli_real_escape_string($conn,$_POST['lastname']);
		$location = mysqli_real_escape_string($conn,$_POST['location']);

		if (!preg_match("/^[a-zA-Z0-9]*$/", $username))
		{
			echo $username;
		}
		else if (!preg_match("/^[a-zA-Z0-9]*$/", $firstname))
		{
			echo $firstname;
		}
		else if (!preg_match("/^[a-zA-Z0-9]*$/", $surname))
		{
			echo $surname;
		}
		else
		{
			$test = "UPDATE userprofile SET username='".$username."' , firstname='".$firstname."', lastname='".$surname."', location='".$location."'WHERE username='".$_SESSION['username']."'";
			if ($conn->query($test) === TRUE)
			{
				echo "Record updated successfully";
				header("Location: profile.php");
				exit();
			}
			else
			{
				echo "Error updating record: " . $conn->error;
				header("Location: profile.php?error=SQL");
				exit();
			}
		}
	}