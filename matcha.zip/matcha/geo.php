<?php
	session_start();
	require 'dbconnections.php';

	$url = "https://d.pub.network/location";
	$json = file_get_contents($url);
    $loc = json_decode($json, true);

//    echo $instagram['cityName'];

	if ($_SESSION['username'])
	{
		$sql = "SELECT location FROM userprofile WHERE username='".$_SESSION['username']."'";
		$result = mysqli_query($conn, $sql);
		$resultCheck = mysqli_num_rows($result);
		if ($resultCheck > 0)
		{
			$row = mysqli_fetch_assoc($result);
			if (!$row['location'])
			{
				$test = "UPDATE userprofile SET location='";
				$test2 = "' WHERE username='";
				$boom = $test.$loc['cityName'].$test2.$_SESSION['username']."'";
				if ($conn->query($boom) === TRUE)
//					echo "Record updated successfully";
				else
//					echo "Error updating record: " . $conn->error;
//				$conn->close();
			}
		}
		else
		{
//			echo "User not found.";
		}
	}