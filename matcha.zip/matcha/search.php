<?php
	include 'header.php';
	require 'dbconnections.php';

	if (!isset($_SESSION['username']))
	{
		header("Location: index.php");
		exit();
	}
?>
<style>
	.search
	{
		display:inline-flex;
		text-align: center;
	}
	.in
	{
		display:inline;
	}
	img
	{
		height: 160px;
		width: 160px;
	}
</style>
<body>
	<div><button id="searchshow">Filter</button></div>
	<div class="search" id="search">
		<div class="in"><p>Age: min</p><input type="text" value="" id="agemin"></div>
		<div class="in"><p>Age: max</p><input type="text" value="" id="agemax"></div>
		<div class="in"><p>Popularity: min</p><input type="text" value="" id="popmin"></div>
		<div class="in"><p>Popularity: max</p><input type="text" value="" id="popmax"></div>
		<div class="in"><p>Location</p><input type="text" value="" id="location"></div>
		<div class="in"><p>Tag</p><input type="text" value="" id="tag"></div>
		<div class="in"><p>Gender</p>
		<select id="gender" name="gender">
			<option value=""></option>
			<option value="Male">Male</option>
			<option value="Female">Female</option>
		</select></div>
		<div class="in"><p>Sexual Orientation</p>
		<select id="Sexual_Orientation" name="Sexual_Orientation">
			<option value=""></option>
			<option value="Heterosexual">Heterosexual</option>
			<option value="Homosexual">Homosexual</option>
			<option value="Bisexual">Bisexual</option>
		</select></div>
	</div>
	<div><button id="sortshow">Sort</button></div>
	<div class="sort" id="sort">
		<label for=""><b class="lab">Age: </b></label>
		<select id="orderage" name="orderage">
			<option value=""></option>
			<option value="age ASC">ASC</option>
			<option value="age DESC">DESC</option>
		</select>
		<label for=""><b class="lab">Location: </b></label>
		<select id="orderlocation" name="orderlocation">
			<option value=""></option>
			<option value="location ASC">ASC</option>
			<option value="location DESC">DESC</option>
		</select>
		<label for=""><b class="lab">Popularity: </b></label>
		<select id="orderpopularity" name="orderpopularity">
			<option value=""></option>
			<option value="popularity_score ASC">ASC</option>
			<option value="popularity_score DESC">DESC</option>
		</select>
		<label for=""><b class="lab">Tags: </b></label>
		<select id="ordertags" name="ordertags">
			<option value=""></option>
			<option value="interest1 ASC">ASC</option>
			<option value="interest1 DESC">DESC</option>
		</select>
	</div>
	<div id="results">
	</div>
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
	var search = 0;
	var sort = 0;
  function fetchdata()
  {
  	var agemin = $("#agemin").val();
  	var agemax = $("#agemax").val();
  	var popmin = $("#popmin").val();
  	var popmax = $("#popmax").val();
  	var location = $("#location").val();
  	var tag = $("#tag").val();
  	var Sexual_Orientation = $("#Sexual_Orientation").val();
  	var gender = $("#gender").val();

  	var orderage = $("#orderage").val();
  	var orderlocation = $("#orderlocation").val();
  	var orderpopularity = $("#orderpopularity").val();
  	var ordertags = $("#ordertags").val();
    $.ajax(
    {
      url: 'http://localhost:8888/searchmysql.php?agemin='+agemin+'&agemax='+agemax+'&location='+location+'&popmin='+popmin+'&popmax='+popmax+'&tags='+tag+'&Sexual_Orientation='+Sexual_Orientation+'&gender='+gender+'&orderage='+orderage+'&orderlocation='+orderlocation+'&orderpopularity='+orderpopularity+'&ordertags='+ordertags+'',
      type: 'post',
      success: function(response)
      {
        $("#results").html(response);
      }
    });
  }
  fetchdata();
  $('#search').hide();
  $('#sort').hide();
  $( "#searchshow" ).click(function()
  {
  	if (search == 0)
  	{
  		$('#search').show();
  		search = 1;

  	}
  	else
  	{
  		$('#search').hide();
  		search = 0;
  	}
  });
    $( "#sortshow" ).click(function()
  {
  	if (sort == 0)
  	{
  		$('#sort').show();
  		sort = 1;

  	}
  	else
  	{
  		$('#sort').hide();
  		sort = 0;
  	}
  	});
  $(document).ready(function()
  {
    setInterval(fetchdata,1000);
  });
</script>