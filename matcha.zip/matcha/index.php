<?php
	
	include 'header.php';
	include 'lastseen.php';
	include 'userdata.php';
	require 'dbconnections.php';

	if (isset($_SESSION['username']))
	{
		$block = checkblock($conn, $_SESSION['username']);
		$sql = "SELECT * FROM userprofile WHERE username='".$_SESSION['username']."'";
		$result = mysqli_query($conn, $sql);
		$resultCheck = mysqli_num_rows($result);
		if ($resultCheck > 0)
		{
			$row = mysqli_fetch_assoc($result);
			if ($row['completed'] == 'no')
			{
				echo "Finish setting up profile.";
				$finish = "no";
				$_SESSION['completed'] = "";
			}
			else
			{
//				echo "Profile Finished.";
				$_SESSION['completed'] = "yes";
				$finish = "yes";
				$interest1 = $row['interest1'];
				$interest2 = $row['interest2'];
				$interest3 = $row['interest3'];
				if ($row['sexual_orientation'])
				{
					if ($row['gender'] == "male" && $row['sexual_orientation'] == 'Heterosexual')
					{
						$gender = 'female';
						$sex = "Heterosexual";
					}
					else if ($row['gender'] == "female" && $row['sexual_orientation'] == 'Heterosexual')
					{
						$gender = 'male';
						$sex = "Heterosexual";
					}
					else if ($row['gender'] == "male" && $row['sexual_orientation'] == 'Homosexual')
					{
						$gender = 'male';
						$sex = "Homosexual";
					}
					else if ($row['gender'] == "female" && $row['sexual_orientation'] == 'Homosexual')
					{
						$gender = 'female';
						$sex = "Homosexual";
					}
					if ($row['sexual_orientation'] == 'Bisexual')
					{
						$sql = "SELECT * FROM userprofile WHERE sexual_orientation='Bisexual' AND location='".$row['location']."'";
						$result = mysqli_query($conn, $sql);
					}
					else
					{
						$sql = "SELECT * FROM userprofile WHERE sexual_orientation='".$sex."' AND gender='".$gender."' AND location='".$row['location']."'";
						$result = mysqli_query($conn, $sql);
					}
				}
				$resultCheck = mysqli_num_rows($result);
				$i = 1;
			}
		}
	}
	else
	{
		header("Location: loginform.php");
		exit();
	}
?>
<head>
	<style>
		.gal
		{
			float: left;
		}
		.row
		{
			display: flex;
			flex-direction: row;
			flex-wrap: wrap;
			justify-content: center;
		}
		.col
		{
			margin-left: 12px;
			width: 250px;
			height: 300px;
			text-align: center;

		}

</style>
</head>
<body>
		<?php 
			if ($resultCheck > 0 && $_SESSION['completed'])
			{
				
				echo "<h2 class='header'>Suggested Profiles</h2><br>";
				echo "<div class='row'>";
				for ($x = 1; $x <= $resultCheck; $x++)
				{
					$row = mysqli_fetch_assoc($result);

					if (in_array($row['username'], $block, TRUE)) 
					{
						continue;
					} 
					
					if ($interest1 == $row['interest1'] || $interest2 == $row['interest2'] || $interest3 == $row['interest3'])
					{
						echo '<div class="col gal">';
						echo "<a target='_blank' href=http://localhost:8888/visitprofile.php?username=".$row['username'].">";
						echo "<img src='images/".$row['profile_picture']."' alt='Cinque Terre' width='270' height='270'>";
						echo "</a>";
						echo "<div class='desc'>".$row['firstname']." ".$row['lastname']."</div></div>";
					}
				}
				echo "</div>";
			}
		?>
</body>