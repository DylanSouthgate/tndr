<?php

	session_start();
	require 'dbconnections.php';

	$sql = "CREATE TABLE userprofile (
	userprofileid int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
	username LONGTEXT,
	firstname LONGTEXT,
	lastname LONGTEXT,
	pwd LONGTEXT,
	email LONGTEXT,
	confirmation LONGTEXT,
	age LONGTEXT,
	gender LONGTEXT,
	sexual_orientation LONGTEXT,
	shortbio LONGTEXT,
	interest1 LONGTEXT,
	interest2 LONGTEXT,
	interest3 LONGTEXT,
	profile_picture LONGTEXT,
	picture1 LONGTEXT,
	picture2 LONGTEXT,
	picture3 LONGTEXT,
	picture4 LONGTEXT,
	location LONGTEXT,
	popularity_score LONGTEXT,
	completed LONGTEXT)";

	$conn->query($sql);

	$sql = "CREATE TABLE notifications (
	notifications int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
	emailsender LONGTEXT,
	emailreciever LONGTEXT,
	message LONGTEXT,
	stat LONGTEXT)";

	$conn->query($sql);

	$sql = "CREATE TABLE messages (
	messagesid int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
	sender LONGTEXT,
	reciever LONGTEXT,
	message LONGTEXT,
	stat LONGTEXT)";

	$conn->query($sql);

	$sql = "CREATE TABLE likes (
	likesid int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
	emailliker LONGTEXT,
	recieveliker LONGTEXT,
	status LONGTEXT)";

	$conn->query($sql);

	$sql = "CREATE TABLE block (
	blockid int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
	username LONGTEXT,
	suspect LONGTEXT)";

	$conn->query($sql);

	$sql = "CREATE TABLE lastseen (
	lastseenid int(11) AUTO_INCREMENT PRIMARY KEY NOT NULL,
	username LONGTEXT,
	status LONGTEXT,
	lastseendate LONGTEXT)";

	$conn->query($sql);