<?php
//21
//	include 'header.php';
	require 'dbconnections.php';
	include 'createtables.php';


	$json = file_get_contents('data/data.json');
    $data = json_decode($json, true);

    foreach ($data as $key => $value)
    {
    		$sql = "INSERT INTO userprofile (username, firstname,lastname,pwd,email,confirmation,age, gender,sexual_orientation,shortbio, interest1, interest2, interest3, profile_picture, picture1, picture2,picture3,picture4,location,popularity_score,completed) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			$stmt = mysqli_stmt_init($conn);
			if (!mysqli_stmt_prepare($stmt ,$sql))
			{
				echo "wrong";
//				header("Location: registerform.php?error=SQL Error");
//				exit();
			}
			else
			{
				mysqli_stmt_bind_param($stmt, "sssssssssssssssssssss", $value['username'],$value['firstname'],$value['lastname'],$value['pwd'],$value['email'],$value['confirmation'],$value['age'],$value['gender'],$value['sexual_orientation'],$value['shortbio'],$value['interest1'],$value['interest2'],$value['interest3'],$value['profile_picture'],$value['picture1'],$value['picture2'],$value['picture3'],$value['picture4'],$value['location'],$value['popularity_score'],$value['complete']);
				mysqli_stmt_execute($stmt);
			}
    }