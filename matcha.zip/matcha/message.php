<?php
	include 'header.php';
	require 'dbconnections.php';

	if ($_SESSION['username'])
	{
		$sql = "SELECT DISTINCT sender FROM messages WHERE reciever='".$_SESSION['username']."' AND stat='unread'";
		$result = mysqli_query($conn, $sql);
		$resultCheck = mysqli_num_rows($result);
		if($resultCheck > 0)
		{
			while ($row = mysqli_fetch_assoc($result))
			{
				echo "<a href=chatapp.php?username=".$row['sender'].">".$row['sender'];
				echo " sent you a message.</a><br>";
			}
		}
	}
?>