<?php
	session_start();
?>
<head>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<style>
  ul
  {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
  }
  li
  {
    float: left;
  }
  li a
  {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
  }
  li a:hover
  {
    background-color: #111;
  }
</style>
</head>
<ul>
  <li><a href="profilecomplete.php">Matcha</a></li>
  <div class="rightnav" style="float:right">
    <?php if ($_SESSION['username']) { ?>
      <li><a class="active" id="mess" href="notifications.php"></a></li>
      <li><a class="active" id="message" href="message.php">Message (0)</a></li>
      <li><a class="active" href="search.php">Search</a></li>
      <li><a class="active" href="pop_score.php">Profile</a></li>
      <li><a class="active" href="history.php">History</a></li>
      <li><a class="active" href="logout.php">Logout</a></li>
    <?php } else { ?>
      <li><a class="active" href="registerform.php">Register</a></li>
      <li><a class="active" href="loginform.php">Login</a></li>
    <?php } ?>
  </div>
</ul>
<script>
  function fetchdata()
  {
    $.ajax(
    {
      url: 'http://localhost:8888/notificationscount.php',
      type: 'post',
      success: function(response)
      {
        $("#mess").html("Notifications (" + response + ")");
      }
    });
    $.ajax(
    {
      url: 'http://localhost:8888/messagecounter.php',
      type: 'post',
      success: function(response)
      {
        $("#message").html("Messages (" + response + ")");
      }
    });
  }
  fetchdata();
  $(document).ready(function()
  {
    setInterval(fetchdata,2000);
  });
</script>