<?php
	include 'header.php';
	echo $_SESSION['completed'];