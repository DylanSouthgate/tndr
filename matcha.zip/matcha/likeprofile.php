<?php

	include 'header.php';
	require 'dbconnections.php';

	function sendnot()
	{
		echo $liker;
	}

	if ($_SESSION['username'])
	{
		$liker = $_SESSION['username'];
		$recieveliker = $_GET['reciever'];
		$status = $_GET['status'];

		$sql = "SELECT * FROM likes WHERE emailliker='".$liker."' AND recieveliker='".$recieveliker."'";
		$result = mysqli_query($conn, $sql);
		$resultCheck = mysqli_num_rows($result);
		if ($resultCheck > 0)
		{
			$test = "UPDATE likes SET status='".$status."' WHERE emailliker='".$_SESSION['username']."' AND recieveliker='".$recieveliker."'";

			if ($conn->query($test) === TRUE)
			{
				echo "";
				header("Location: match.php?username=".$_GET['username']);
				exit();
			}
			$sql = "INSERT INTO notifications (emailsender, emailreciever,message, stat) VALUES (?,?,?,?)";
			$stmt = mysqli_stmt_init($conn);
			if (!mysqli_stmt_prepare($stmt ,$sql))
			{
			}
			else
			{
				$read = "unread";
				mysqli_stmt_bind_param($stmt, "ssss", $liker, $recieveliker, $status, $read);
				mysqli_stmt_execute($stmt);
			}

			header("Location: allprofile.php?username=".$_GET['username']);
			exit();
		}
		else
		{
			$sql = "INSERT INTO likes (emailliker, recieveliker, status) VALUES (?, ?, ?)";
			$stmt = mysqli_stmt_init($conn);
			if (!mysqli_stmt_prepare($stmt ,$sql))
			{
//				header("Location: registerform.php?error=SQL Error");
//				exit();
			}
			else
			{
				mysqli_stmt_bind_param($stmt, "sss", $liker, $recieveliker, $status);
				mysqli_stmt_execute($stmt);
			}
			$sql = "INSERT INTO notifications (emailsender, emailreciever,message, stat) VALUES (?,?,?,?)";
			$stmt = mysqli_stmt_init($conn);
			if (!mysqli_stmt_prepare($stmt ,$sql))
			{
			}
			else
			{
				$read = "unread";
				mysqli_stmt_bind_param($stmt, "ssss", $liker, $recieveliker, $status, $read);
				mysqli_stmt_execute($stmt);
			}
			header("Location: match.php?username=".$_GET['username']);
			exit();
		}
	}