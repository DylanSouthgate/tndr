<?php

$servername = "localhost";
$dbUsername = "root";
$dbPassword = "Boom";
$dbName = "matcha2";

$conn1 = mysqli_connect($servername, $dbUsername, $dbPassword, $dbName);

if (!$conn1)
{
	die("Connection failed: ".mysqli_connect_error());
}