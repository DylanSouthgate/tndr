<?php
	require 'dbconnections.php';

	function getdatabyusername($conn, $username)
	{
		$sqlstring = "SELECT * FROM userprofile WHERE username='".$username."'";
		$results = $conn->query($sqlstring);

		if ($results->num_rows > 0)
		{
			$user = $results->fetch_assoc();
			return $user;
		}
		else
		{
//			echo "0 results";
		}
	}

	function geolocation($conn, $username)
	{
		$url = "https://d.pub.network/location";
		$json = file_get_contents($url);
		$loc = json_decode($json, true);

		$sqlstring = "SELECT location FROM userprofile WHERE username='".$username."'";
		$results = $conn->query($sqlstring);

		if ($results->num_rows > 0)
		{
			$user = $results->fetch_assoc();
			if (!$user['location'])
			{
				$test = "UPDATE userprofile SET location='".$loc['cityName']."' WHERE username='".$username."'";
				if ($conn->query($test) === TRUE)
					echo "";
				else
				{
					echo "";
				}
			}
		}
		else
		{
//			echo "0 results";
		}
	}

	function checkblock($conn, $username)
	{
		$sqlstring = "SELECT * FROM block WHERE username='".$username."'";
		$results = $conn->query($sqlstring);

		if ($results->num_rows > 0)
		{
			while ($row = $results->fetch_assoc())
			{
				$data[] = $row['suspect'];
			}
			return $data;
		}
		else
		{
//			echo "0 results";
		}
	}

	function selectby($conn, $string)
	{
		$sqlstring = $string;
		$results = $conn->query($sqlstring);

		if ($results->num_rows > 0)
		{
			while ($row = $results->fetch_assoc())
			{
				$data[] = $row;
			}
			return $data;
		}
		else
		{
//			echo "0 results";
		}
	}