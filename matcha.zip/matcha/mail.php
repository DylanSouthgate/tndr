<?php
	require 'includes/PHPMailer.php';
	require 'includes/SMTP.php';
	require 'includes/Exception.php';
	use PHPMailer\PHPMailer\PHPMailer;
	use PHPMailer\PHPMailer\SMTP;
	use PHPMailer\PHPMailer\Exception;
	include 'header.php';
	
	function sendmail($mail1)
	{
		$mail = new PHPMailer();
		$mail->isSMTP();
		$mail->Host = "smtp.gmail.com";
		$mail->SMTPAuth = true;
		$mail->SMTPSecure = "tls";
		$mail->Port = "587";
		$mail->Username = "dsouthga@student.wethinkcode.co.za";
		$mail->Password = "Lexmarks098";
		$mail->Subject = "Email Confirmation";
		$mail->setFrom('dsouthga@student.wethinkcode.co.za');
		$mail->isHTML(true);

		$token = md5($mail1);
	
		$mail->Body = "Click to activate Matcha Account; http://localhost:8888/confirmation.php?email=".$mail1."&token=".$token;
	
		$mail->addAddress($mail1);
	
		if ( $mail->send() )
		echo "Email Sent..!";
		{
			header("Location: loginform.php");
			exit();
		}
		echo "Message could not be sent. Mailer Error: "{$mail->ErrorInfo};

		$mail->smtpClose();
	}
	sendmail($_GET['email']);
?>
