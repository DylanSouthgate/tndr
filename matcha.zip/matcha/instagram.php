<?php

    include 'header.php';
//    $username = $_GET['username'];

    $username = $_POST['username'];

    $url = "https://www.instagram.com/".$username."/?__a=1";

    $json = file_get_contents($url);
    $instagram = json_decode($json, true);

    $i = 0;
//    echo '<form action="/action_page.php">';
?>
<body>
    <div class="col">
        <form action="instagram.php" method="post">
            <label for="instagram"><b class="lab">Instagram Id</b></label>
            <input type="text" class="form-control" value="<?php echo $username;?>" name="username" id="username" required><br>
            <div><input type="submit" name="search" value="Search Images"></div>
        </form>
    </div>
</body>
<?php
    foreach ($instagram['graphql']['user']['edge_owner_to_timeline_media']['edges'] as $key => $value)
    {
        foreach ($value as $test => $proof)
        {
            foreach ($proof as $text => $image)
            {
                if ($text == "thumbnail_src")
                {
                    $i += 1;
//                    echo "<div>";
//                    echo "<input type='checkbox' id=picture".$i." name=picture".$i." value=picture".$i;
                    echo "<label for='myCheckbox1'><img height=270 weight=270 src=".$image."></label></div>";
                    echo "<form action='instagramupload.php' method='post'>";
                    echo "<input type='text' class='form-control' name='link' id='link' value='".$image."'hidden required>";
                    echo "<select id='image' name='image' required>";
                        echo "<option value='profile_picture'>profile_picture</option>";
                        echo "<option value='picture1'>picture1</option>";
                        echo "<option value='picture2'>picture2</option>";
                        echo "<option value='picture3'>picture3</option>";
                        echo "<option value='picture4'>picture4</option>";
                    echo "</select>";
                    echo "<div class='form-label'>";
                    echo "<button type='submit' name='upload' class='button'>Upload</button>";
                    echo "</div>";
                    echo "</form>";
                }
            }
        }
    }
//    echo '</form>';
?>