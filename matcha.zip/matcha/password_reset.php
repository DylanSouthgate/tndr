<?php
	require 'includes/PHPMailer.php';
	require 'includes/SMTP.php';
	require 'includes/Exception.php';
	use PHPMailer\PHPMailer\PHPMailer;
	use PHPMailer\PHPMailer\SMTP;
	use PHPMailer\PHPMailer\Exception;
	require 'dbconnections.php';
	include 'header.php';

	function sendmail($mail1, $password)
	{
		$mail = new PHPMailer();
		$mail->isSMTP();
		$mail->Host = "smtp.gmail.com";
		$mail->SMTPAuth = true;
		$mail->SMTPSecure = "tls";
		$mail->Port = "587";
		$mail->Username = "dsouthga@student.wethinkcode.co.za";
		$mail->Password = "Lexmarks098";
		$mail->Subject = "Email Confirmation";
		$mail->setFrom('dsouthga@student.wethinkcode.co.za');
		$mail->isHTML(true);

		$token = md5($mail1);
	
		$mail->Body = "New Password :".$password;
	
		$mail->addAddress($mail1);
	
		if ( $mail->send() )
		echo "Email Sent..!";
		{
//			header("Location: loginform.php");
//			exit();
		}
		echo "Message could not be sent. Mailer Error: "{$mail->ErrorInfo};

		$mail->smtpClose();
	}

	if (isset($_POST['password_reset']))
	{
		$email = $_POST['email'];
		if (!empty($email))
		{
			$sql = "SELECT * FROM userprofile WHERE email='".$email."'";
			$result = mysqli_query($conn, $sql);

			$resultCheck = mysqli_num_rows($result);
			if ($resultCheck > 0)
			{
				$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
				$randomString = '';

				for ($i = 0; $i < 11; $i++)
				{ 
					$index = rand(0, strlen($characters) - 1);
					$randomString .= $characters[$index]; 
				}
				$test = "UPDATE userprofile SET pwd='".md5($randomString)."' WHERE email='".$email."'";
				$conn->query($test);
				sendmail($email, $randomString);
			}
			else
			{
				header("Location: password_reset.php?error=Account not found.");
				exit();
			}
		}
	}
?>
<form action="password_reset.php" method="post">
	<div class="container">
		<h1>Password Reset</h1>

		<h3><?php if (isset($_GET['error'])) { echo "Error: ".$_GET['error']; }?></h3>

		<label for="email"><b>Email</b></label>
		<input type="text" class="form-control" value="<?php echo $_GET['email'];?>" placeholder="Enter Email" name="email" id="email" required>

		<button type="submit" name="password_reset" class="btn btn-primary">Submit</button>

	</div>
</form>