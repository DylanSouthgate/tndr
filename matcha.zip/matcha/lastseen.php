<?php
	session_start();
	require 'dbconnections.php';

	if ($_SESSION['username'])
	{
		$sql = "SELECT * FROM lastseen WHERE username='".$_SESSION['username']."'";
		$result = mysqli_query($conn, $sql);
		$resultCheck = mysqli_num_rows($result);
		$row = mysqli_fetch_assoc($result);
		if ($resultCheck == 0)
		{
			$sql = "INSERT INTO lastseen (username, status) VALUES (?, ?)";
			$stmt = mysqli_stmt_init($conn);
			if (!mysqli_stmt_prepare($stmt ,$sql))
			{
			}
			else
			{
				$status = "online";
				mysqli_stmt_bind_param($stmt, "ss", $_SESSION['username'], $status);
				mysqli_stmt_execute($stmt);
			}
		}
		else if ($row['status'] == "offline")
		{
			$test = "UPDATE lastseen SET status='online' WHERE username='".$_SESSION['username']."'";
			$conn->query($test);
		}
	}