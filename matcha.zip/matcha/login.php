<?php
	include 'header.php';
	if (isset($_POST['login-submit']))
	{
		require 'dbconnections.php';

		$email = mysqli_real_escape_string($conn,$_POST['email']);
		$password = mysqli_real_escape_string($conn,$_POST['pwd']);

		if (!empty($email) && !empty($password))
		{

			$sql = "SELECT * FROM userprofile WHERE email='".$email."' AND pwd='".md5($password)."'";
			$result = mysqli_query($conn, $sql);

			$resultCheck = mysqli_num_rows($result);
			$row = mysqli_fetch_assoc($result);
			if ($resultCheck > 0)
			{		
				if ($row['confirmation'] == "no")
				{
					header("Location: loginform.php?error=Confirm email address before login.");
					exit();
				}
				else
				{
					$_SESSION['username'] = $row['username'];
				}
			}
			else
			{
				header("Location: loginform.php?error=Crednetials Wrong.");
				exit();
			}
		}
	}
	else
	{
		header("Location: loginform.php");
			exit();
	}

?>