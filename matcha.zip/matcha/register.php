<?php
include 'header.php';
	if (isset($_POST['signup-submit']))
	{
		require 'dbconnections.php';

		$username = mysqli_real_escape_string($conn,$_POST['username']);
		$firstname = mysqli_real_escape_string($conn,$_POST['firstname']);
		$surname = mysqli_real_escape_string($conn,$_POST['lastname']);
		$email = mysqli_real_escape_string($conn,$_POST['email']);
		$password = mysqli_real_escape_string($conn,$_POST['pwd']);
		$password2 = mysqli_real_escape_string($conn,$_POST['pwd2']);
		$confirmation = "no";

		if (empty($username) || empty($firstname) || empty($surname) || empty($email) || empty($password) || empty($password2))
		{
			header("Location: registerform.php?error=emtypfields&username=".$username."&firstname=".$firstname."&lastname=".$surname."&email=".$email);
			exit();
		}
		else if (!filter_var($email, FILTER_VALIDATE_EMAIL))
		{
			header("Location: registerform.php?error=Invalid Email&username=".$username."&firstname=".$firstname."&lastname=".$surname);
			exit();
		}
		else if (!preg_match("/^[a-zA-Z0-9]*$/", $username))
		{
			header("Location: registerform.php?error=Invalid Username&firstname=".$firstname."&lastname=".$surname."&email=".$email);
			exit();
		}
		else if (!preg_match("/^[a-zA-Z0-9]*$/", $firstname))
		{
			header("Location: registerform.php?error=Invalid First Name&username=".$username."&lastname=".$surname."&email=".$email);
			exit();
		}
		else if (!preg_match("/^[a-zA-Z0-9]*$/", $surname))
		{
			header("Location: registerform.php?error=Invalid First Name&username=".$username."&lastname=".$surname."&email=".$email);
			exit();
		}
		else if (!preg_match('/[A-Z]/', $password) && !preg_match('/[A-Z]/', $password))
		{
			header("Location: registerform.php?error=Password too simple&username=".$username."&firstname=".$firstname."&email=".$email."&lastname=".$surname);
			exit();
		}
		else if (!preg_match("/^[a-zA-Z0-9]*$/", $password))
		{
			header("Location: registerform.php?error=Invalid Surname&username=".$username."&firstname=".$firstname."&email=".$email);
			exit();
		}
		else if ($password != $password2)
		{
			header("Location: registerform.php?error=Passwords do not match&username=".$username."&firstname=".$firstname."&lastname=".$surname."&email=".$email);
			exit();
		}
		else
		{
			$sql = "SELECT username FROM userprofile WHERE username=?";
			$stmt = mysqli_stmt_init($conn);

			if (!mysqli_stmt_prepare($stmt ,$sql))
			{
				header("Location: registerform.php?error=SQL Error&username=".$username."&firstname=".$firstname."&lastname=".$surname."&email=".$email);
				exit();
			}
			else
			{
				mysqli_stmt_bind_param($stmt, "s", $username);
				mysqli_stmt_execute($stmt);
				mysqli_stmt_store_result($stmt);
				$resultCheck = mysqli_stmt_num_rows($stmt);
				if ($resultCheck > 0)
				{
					header("Location: registerform.php?error=Username Taken&firstname=".$firstname."&lastname=".$surname."&email=".$email);
					exit();
				}
			}

			$sql = "SELECT email FROM userprofile WHERE email=?";
			$stmt = mysqli_stmt_init($conn);

			if (!mysqli_stmt_prepare($stmt ,$sql))
			{
				header("Location: registerform.php?error=SQL Error&username=".$username."&firstname=".$firstname."&lastname=".$surname."&email=".$email);
				exit();
			}
			else
			{
				mysqli_stmt_bind_param($stmt, "s", $email);
				mysqli_stmt_execute($stmt);
				mysqli_stmt_store_result($stmt);
				$resultCheck = mysqli_stmt_num_rows($stmt);
				if ($resultCheck > 0)
				{
					header("Location: registerform.php?error=Email Taken&username=".$username."&firstname=".$firstname."&lastname=".$surname);
					exit();
				}
			}

			$sql = "INSERT INTO userprofile (username, firstname, lastname, email, pwd, confirmation) VALUES (?, ?, ?, ?, ?, ?)";
			$stmt = mysqli_stmt_init($conn);
			if (!mysqli_stmt_prepare($stmt ,$sql))
			{
				header("Location: registerform.php?error=SQL Error");
				exit();
			}
			else
			{
				$hadshedpewd = md5($password);
				mysqli_stmt_bind_param($stmt, "ssssss", $username, $firstname, $surname, $email , $hadshedpewd, $confirmation);
				mysqli_stmt_execute($stmt);
				header("Location: mail.php?email=".$email);
				exit();
			}
		}
	}
	else
	{
		header("Location: index.php");
			exit();
	}

?>