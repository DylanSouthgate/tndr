<?php
	session_start();
	require 'dbconnections.php';
	include 'userdata.php';
	geolocation($conn, $_SESSION['username']);