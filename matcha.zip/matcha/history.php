<?php
	include 'header.php';
	require 'dbconnections.php';


	if ($_SESSION['username'])
	{
		$sql = "SELECT * FROM notifications WHERE emailreciever='".$_SESSION['username']."'";
		$result = mysqli_query($conn, $sql);
		$resultCheck = mysqli_num_rows($result);
		if ($resultCheck > 0)
		{
			while ($resultCheck > 0)
			{
				$row = mysqli_fetch_assoc($result);
				$message = $row['message'];
					$boom = "SELECT username FROM userprofile WHERE username='".$row['emailsender']."'";
					$result1 = mysqli_query($conn, $boom);
					$row1 = mysqli_fetch_assoc($result1);
					if ($row['message'] == 'like')
						echo "<p>".$row1['username']." liked you.</p><br>";
					else if ($row['message'] == 'dislike')
						echo "<p>".$row1['username']." disliked you.</p><br>";
					else if ($row['message'] == 'match')
						echo "<a href=allprofile.php?username=".$row1['username']."><p>You and ".$row['emailsender']." have matched.</p></a><br>";
					else
						echo "<a href=allprofile.php?username=".$row1['username']."><p>".$row1['username'].$row['message']."</p></a><br>";
				$resultCheck--;
			}
			$test = "UPDATE notifications SET stat='read' WHERE emailreciever='".$_SESSION['username']."'";
			$conn->query($test);
		}
	}