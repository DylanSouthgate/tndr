<?php 
	include 'header.php';
	if (!$_SESSION['username'] && !$_GET['username'])
	{
		header("Location: index.php");
		exit();
	}
?>
<head>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>
<style>
	body
	{ 
		padding: 10px; 
		margin: 0; 
	} 
	div.test
	{
		position: fixed;
		bottom: 0px;
		text-align: center;
	}
</style>
<body>
		<div class="mess1" id=mess1>
		</div>
		<div class="fixed-bottom">
			<form action="chatsetup.php" method="post">
			<input type="text" class="form-control" placeholder="Enter Message" name="message" id="message" required><br>
			<input type="hidden" name="sender" id="sender" value=<?php echo $_SESSION['username'];?>>
			<input type="hidden" name="reciever" id="reciever" value=<?php echo $_GET['username'];?>>
			<button type="submit" name="send-submit" class="btn btn-primary">Send</button>
		</form>
		</div>
</body>
<script>
	

	function fetchdata()
	{
		$.ajax(
		{
			url: 'http://localhost:8888/getmessages.php?username=<?php echo $_GET['username'];?>',
			type: 'post',
			success: function(response)
			{
				$("#mess1").html(response);
//				alert(response);
			}
		});
	}
	fetchdata();
	$(document).ready(function()
	{
		setInterval(fetchdata,2000);
	});
</script>